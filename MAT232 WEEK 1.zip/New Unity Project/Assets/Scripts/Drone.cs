﻿using UnityEngine;

/*
 * Code written by Ajitesh Misra
 * This code moves the drone object around the 'building'
 * 
 */

public class Drone : MonoBehaviour {

    [Header("Movement Variables")]
    public float buildingWidth = 30;
    public float buildingLength = 40;
    public float buildingHeight = 72;

    [Space]

    [Header("Extras")]
    public float buffer = 1;
    [Range(1, 5)]
    public float rotationsToMake = 2f;

    [HideInInspector]
    public bool reachedDest = false;

    private float time = 0;
    private float rad = 0;
	// Called on the first frame of the game
	void Start () {
        rad = CalculateRadius();
	}
	
	// Update is called once per frame
	void Update () {
        // update time
        time += Time.deltaTime;

        // if we have reached the top
        if (transform.position.y > buildingHeight)
        {
            // Note this is a quick and dirty way to do this
            // this is the least efficient way to do it
            reachedDest = true;
        }

        // If pi / 2 seconds have passed
        // start moving the drone
        // 0° in unity is (1,0) on the unit circle, not (0,1)
        if (time > 0.5f * Mathf.PI)
        {
            // get the direction to move in
            Vector2 direction = Direction(time, rad);

            // Unity has the y axis be the vertical
            // so I had to switch z and y
            // for vertical movement, we want to reach the top at a known time
            // so I divided height by time to get the needed movement
            Vector3 newPos = new Vector3(direction.x,                     // horizontal direction
                buildingHeight / (rotationsToMake *  2* Mathf.PI),        // vertical direction
                direction.y);                                             // forward direction

            // If the drone has not reached the destination yet
            // only then move the drone
            if (!reachedDest)
            {
                // Move the drone in the proper direction
                // multiplying by Time.deltaTime makes the movement 
                // frame rate independant 
                transform.Translate(newPos * Time.deltaTime);
            }
        }
    }

    private float CalculateRadius()
    {
        float output = 0f;

        // output = sqrt(L^2 + W^2)
        output = Mathf.Sqrt(Mathf.Pow(buildingLength / 2, 2) + Mathf.Pow(buildingWidth / 2, 2));
        // Add a buffer to radius so edge of drone does not hit building
        output += buffer;

        return output;
    }

    private Vector2 Direction(float time, float radius)
    {
        /* HOW THIS WORKS:
         * overhead path of the drone is as follows:
         * (radius * Cos(time), radius * Sin(time))
         * direction to move is the derivative of that
         * 
         * dy/dt = radius * Cos(time)
         * dx/dt = - radius * Sin(time)
         * 
         * dy/dx = - Cos(time) / Sin(time)
         *          ~~or just -Cot(time)~~
         *          
         * Return this as a 2D vector so there is no chance of 
         * dividing by zero
         */

        if (reachedDest)
        {
            // if at the end, do not move
            return Vector2.zero;
        }
        else
        {
            // init the output
            Vector2 output = Vector2.zero;

            // set output to the proper derivative
            output = new Vector2(radius * Mathf.Cos(time), -radius *Mathf.Sin(time));

            // return the new output
            return output;
        }
    }
}
